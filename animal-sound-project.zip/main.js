function playSound() {
  const audio = document.getElementById("questionSound");
  audio.play();
}

function checkAnswer(answer) {
  const result = document.getElementById("result");

  if (answer === "گاو") {
    result.textContent = "آفرین! خیلی خوب بود ✅";
    result.style.color = "green";
  } else {
    result.textContent = `❌ پاسخ درست: بز — بیشتر حواست باشه!`;
    result.style.color = "red";
  }
}